<?php
if(!$s_idx){
    echo "
        <script type=\"text/javascript\">
            alert(\"잘못된 접근입니다.\");
            location.href = \"http://localhost/web_project\";
        </script>
    ";
    exit;
};
?>